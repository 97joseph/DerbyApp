//
//  AppDelegate.h
//  HelloWorld
//
//  Created by Jeff Mcwherter on 12/11/11.
//  Copyright (c) 2011 Gravity Works Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
