//
//  ViewController.h
//  HelloWorld
//
//  Created by Jeff Mcwherter on 12/11/11.
//  Copyright (c) 2011 Gravity Works Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *lblChangeMe;

@end
