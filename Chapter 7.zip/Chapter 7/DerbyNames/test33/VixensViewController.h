#import <UIKit/UIKit.h>
NSArray *listData;

@interface VixensViewController : UITableViewController
@property(nonatomic, retain) NSArray *listData;
@end
