#import <UIKit/UIKit.h>

@interface LeagueTableViewController : UITableViewController
@property(nonatomic, retain) NSArray *listData;
@end
