#import <UIKit/UIKit.h>

@interface DetailViewController : UITableViewController

@property (nonatomic, retain) NSString *data;
@property(nonatomic, retain) NSArray *listData;

@end
