package com.gravityworks.derbydata;

public class DerbyName {
	private int DerbyNameId;
	private String Name;
	private String Number;
	private String League;
	
	public int getDerbyNameId() {
		return DerbyNameId;
	}
	public void setDerbyNameId(int derbyNameId) {
		DerbyNameId = derbyNameId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getNumber() {
		return Number;
	}
	public void setNumber(String number) {
		Number = number;
	}
	public String getLeague() {
		return League;
	}
	public void setLeague(String league) {
		League = league;
	}	
}
